from django.urls import path
from . import views



urlpatterns = [
    path('home/',views.home, name = 'home'),
    path('create/', views.create, name='create'),
    path('main/<int:pk>',views.main,name ='main'),
    path('logout/', views.logout_view, name='logout'),
    path('delete/', views.delete, name='delete'),
    path('update/<int:pk>',views.user_update, name='update'),
    path('deletes/<int:pk>/',views.deletes, name = 'deletes'),
    # path('list',views.list,name='list'),
    path('login/', views.user_login, name='login'),
    path('upi/',views.upi,name= 'upi'),
    path('set-upi/', views.set_upi, name='set_upi'),
    path('transfer/', views.transfer_money, name='transfer'),
    path('deposit/',views.deposit_by_account, name = 'deposit'),
    path('admin-panel/', views.admin_panel, name='admin_panel'),
    path('register-user/', views.register, name='register'),
    path("pending-users/", views.pending_users, name="pending_users"),
    path("approve-user/<int:pk>/", views.approve_user, name="approve_user"),
    path('notifications',views.notifications, name = 'notifications'),
    path('payment-success/', views.payment_success, name='payment_success'),
     path('update_pending_neft_transactions/', views.update_pending_neft_transactions, name='update_pending_neft_transactions'),
    path('bank_transfer', views.bank_transfer, name='bank_transfer'),
    path('get_account_name/', views.get_account_name, name='get_account_name'),
    path('statement/', views.account_statement, name='statement'),
    path('statement/download/', views.download_statement, name='download_statement'),
    path('beneficiaries/', views.beneficiary_dashboard, name='beneficiary_dashboard'),
    # path('beneficiaries/delete/<int:pk>/', views.delete_beneficiary, name='delete_beneficiary'),
    path('edit/<int:pk>/', views.edit_beneficiary, name='edit_beneficiary'),
    path('beneficiaries/<int:pk>/pay/', views.pay_beneficiary, name='pay_beneficiary'),
    path('payment-success/', views.payment_success, name='payment_success'),
]
