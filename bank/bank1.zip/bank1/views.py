from datetime import timedelta
from urllib import request
from django.db.models import Value, CharField
from django.utils import timezone
from decimal import Decimal, InvalidOperation
from django.contrib import messages
from django.http import HttpResponse, HttpResponseForbidden, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout,authenticate,login as auth_login
from .forms import BeneficiaryForm, DepositForm, PaymentForm, TransferForm, UPIForm, UserForm
from .models import BankTransferForm, Beneficiary, Notification, Transaction, UserAccount, UserProfile
from django.template.loader import get_template
from xhtml2pdf import pisa


#Admin panel
def admin_panel(request):
    selected = None
    users = []
    pending_users = []

    if request.method == 'POST':
        if 'option' in request.POST:
            selected = request.POST.get('option')

        # Approving a user
        if 'approve_user' in request.POST:
            user_id = request.POST.get('approve_user')
            acc_number = request.POST.get('account_number')
            try:
                user = User.objects.get(id=user_id)
                profile = user.userprofile
                profile.account_number = acc_number
                profile.is_approved = True
                profile.save()
            except:
                pass
            selected = 'add'

        # Deposit Money
        if 'account_number' in request.POST and 'amount' in request.POST and 'approve_user' not in request.POST:
           acc_number = request.POST.get('account_number')
           amount = Decimal(request.POST.get('amount'))
           try:
                profile = UserProfile.objects.get(account_number=acc_number)
                profile.balance += amount
                profile.save()

                # ✅ ADD THIS BLOCK
                Transaction.objects.create(
                    sender=None,
                    receiver=profile.user,
                    amount=amount,
                    method='Deposit',
                    status='completed'
                )

                # Notification
                Notification.objects.create(
                    user=profile.user,
                    message=f"₹{amount} credited to your account."
                )
                messages.success(request, f"✅ ₹{amount} credited to {profile.user.get_full_name()} (Account {acc_number}).")

           except UserProfile.DoesNotExist:
                 messages.error(request, "❌ Account not found.")
                 selected = 'deposit'

    if selected == 'users':
        users = User.objects.filter(userprofile__is_approved=True)

    if selected == 'add':
        pending_users = User.objects.filter(userprofile__is_approved=False)

    return render(request, 'bank1/admin_dashboard.html', {
        'selected': selected,
        'users': users,
        'pending_users': pending_users
    })



def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        email = request.POST["email"]
        user = User.objects.create_user(username=username, password=password, email=email)
        messages.success(request, "Registered successfully. Await admin approval.")
        return redirect("login")
    return render(request, "register.html")

def pending_users(request):
    if not request.user.is_superuser:
        return HttpResponseForbidden()
    pending = UserProfile.objects.filter(is_approved=False)
    return render(request, "admin_pending_users.html", {"pending_users": pending})

def approve_user(request, pk):
    profile = UserProfile.objects.get(pk=pk)
    if request.method == "POST":
        acc_no = request.POST["account_number"]
        profile.account_number = acc_no
        profile.is_approved = True
        profile.save()
        messages.success(request, "User approved successfully.")
        return redirect("pending_users")
    return render(request, "approve_user.html", {"profile": profile})

def main(request,pk):
    user = User.objects.get(pk=pk)
    return render(request, 'bank1/home.html')
     


@login_required
def home(request):
    upi_id = None
    try:
        upi_id = request.user.userprofile.upi_id
    except UserProfile.DoesNotExist:
        pass

    users = User.objects.all()
    notifications = request.user.notifications.all().order_by('-created_at')[:5]

    return render(request, 'bank1/home.html', {
        'users': users,
        'upi_id': upi_id,
        'notifications': notifications
    })



# def list(request):
#     users = User.objects.all()
#     return render(request,'bank1/user_list.html',{'users': users})

def create(request):
    if request.method == "POST":
        form = UserForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data["password"])
            user.save()
            UserProfile.objects.get_or_create(user=user)
            return redirect('login')
    else:
        form = UserForm()
    return render(request, 'bank1/create.html', {'form': form})




def logout_view(request):
    logout(request)
    return redirect('home')

@login_required
def delete(request):
    user = request.user
    logout(request)
    user.delete()
    return redirect('main')

def user_update(request,pk):
    user = get_object_or_404(User, pk = pk)
    if request.method == "POST":
        form = UserForm(request.POST, instance = user)
        if form.is_valid():
            form.save()
            return redirect('user_list')
    else:
        form = UserForm(instance = user)
    return  render(request, 'bank1/create.html',{'form':form})

def deletes(request,pk):
    user =get_object_or_404(User, pk =pk)
    if request.method == "POST":
        user.delete()
        return redirect('list')
    return render(request, 'bank1/deletes.html', {'user':user}) 

def user_login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(username=username, password=password)
        if user:
            if user.userprofile.is_approved:
                login(request, user)
                return redirect("home")
            else:
                messages.error(request, "Wait for admin approval.")
        else:
            messages.error(request, "Invalid credentials.")
    return render(request, "bank1/login.html")

# Services started

def upi(request):
    return render(request,'bank1/upi.html')


#Upi
@login_required
def set_upi(request):
    # Ensure profile exists
    profile, created = UserProfile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        upi = request.POST.get("upi_id")
        ifsc = request.POST.get("ifsc_code")
        profile.upi_id = upi
        profile.ifsc_code = ifsc
        profile.save()
        return redirect('home')
    return render(request, 'bank1/set_upi.html')


@login_required
def transfer(request):
    profile = request.user.userprofile
    if not profile.upi_id:
        return redirect('set_upi')
    
@login_required
def profile_view(request):
    upi_id = None
    if hasattr(request.user, 'userprofile'):
        upi_id = request.user.userprofile.upi_id
    return render(request, 'bank1/home.html', {'upi_id': upi_id}) 

#UPI Transfer
@login_required
def transfer_money(request):
    form = TransferForm()

    if request.method == 'POST':
        form = TransferForm(request.POST)
        if form.is_valid():
            receiver_upi = form.cleaned_data['receiver_upi']
            amount = form.cleaned_data['amount']

            try:
                receiver_profile = UserProfile.objects.get(upi_id=receiver_upi)
                sender_profile = request.user.userprofile

                if receiver_profile == sender_profile:
                    messages.error(request, "You cannot send money to yourself.")
                    return redirect('transfer')

                if sender_profile.balance < amount:
                    messages.error(request, "Insufficient balance.")
                else:
                    # Transfer
                    sender_profile.balance -= amount
                    receiver_profile.balance += amount
                    sender_profile.save()
                    receiver_profile.save()

                    txn = Transaction.objects.create(
                        sender=request.user,
                        receiver=receiver_profile.user,
                        amount=amount,
                        method='UPI',  # ✅ Explicitly set method
                        status='completed',
                        timestamp=timezone.now()
                    )

                    # Notifications
                    Notification.objects.create(
                        user=request.user,
                        message=f"₹{amount} debited for transfer to {receiver_profile.user.username} ({receiver_upi})"
                    )
                    Notification.objects.create(
                        user=receiver_profile.user,
                        message=f"₹{amount} received from {request.user.username} ({sender_profile.upi_id})"
                    )

                    #Save info in session
                    request.session['payment_success_data'] = {
                        'amount': str(amount),
                        'receiver_name': receiver_profile.user.get_full_name(),
                        'sender_name': request.user.get_full_name(),
                        'date': timezone.now().strftime("%d %b %Y, %I:%M %p")
                    }

                    return redirect('payment_success')

            except UserProfile.DoesNotExist:
                messages.error(request, "No user found with that UPI ID.")

    return render(request, 'bank1/transfer.html', {'form': form})


@login_required
def payment_success(request):
    data = request.session.pop('payment_success_data', None)
    if not data:
        return redirect('home')  # fallback

    return render(request, 'bank1/payment_success.html', data)    


#Deposite money by admin
@login_required
def deposit_by_account(request):
    if request.method == 'POST':
        form = DepositForm(request.POST)
        if form.is_valid():
            acc_no = form.cleaned_data['account_number']
            amount = form.cleaned_data['amount']
            try:
                profile = UserProfile.objects.get(account_number=acc_no)
                profile.balance += amount
                profile.save()
                messages.success(request, f"₹{amount} deposited into account {acc_no}")
            except UserProfile.DoesNotExist:
                messages.error(request, "Account number not found.")
    else:
        form = DepositForm()
    return render(request, 'bank1/deposit_account.html', {'form': form})


@login_required
def notifications(request):
    notifications = request.user.notifications.all().order_by('-created_at')
    return render(request, "bank1/notifications.html", {"notifications": notifications})

# NEFT and IMPS
def update_pending_neft_transactions():
    now = timezone.now()
    pending_txns = Transaction.objects.filter(
        method='NEFT',
        status='pending',
        scheduled_time__lte=now
    )
    for tx in pending_txns:
        tx.status = 'completed'
        tx.receiver.userprofile.balance += tx.amount
        tx.receiver.userprofile.save()
        tx.save()

@login_required
def bank_transfer(request):
    update_pending_neft_transactions()
    form = BankTransferForm()
    # pending_transactions = Transaction.objects.filter(sender=request.user, status='pending').order_by('-timestamp')

    if request.method == 'POST':
        form = BankTransferForm(request.POST)
        if form.is_valid():
            acc_no = form.cleaned_data['receiver_account_number']
            amount = form.cleaned_data['amount']
            method = form.cleaned_data['method'].upper()

            try:
                receiver_profile = UserProfile.objects.get(account_number=acc_no)
                sender_profile = request.user.userprofile

                if receiver_profile == sender_profile:
                    messages.error(request, "Cannot transfer to your own account.")
                elif sender_profile.balance < amount:
                    messages.error(request, "Insufficient balance.")
                else:
                    sender_profile.balance -= amount
                    sender_profile.save()

                    if method == 'NEFT':
                        Transaction.objects.create(
                            sender=request.user,
                            receiver=receiver_profile.user,
                            amount=amount,
                            method='NEFT',
                            status='pending',
                            scheduled_time=timezone.now() + timedelta(minutes=30)
                        )
                        messages.success(request, f"NEFT initiated. ₹{amount} will be credited in 30–60 minutes.")

                    else:  # IMPS
                        receiver_profile.balance += amount
                        receiver_profile.save()

                        Transaction.objects.create(
                            sender=request.user,
                            receiver=receiver_profile.user,
                            amount=amount,
                            method='IMPS',
                            status='completed'
                        )
                        messages.success(request, f"IMPS successful. ₹{amount} sent instantly.")

                    return redirect('bank_transfer')

            except UserProfile.DoesNotExist:
                messages.error(request, "Account number not found.")

    neft_transactions = Transaction.objects.filter(
    sender=request.user,
    method='NEFT'
    ).order_by('-scheduled_time')
    
    return render(request, 'bank1/neft.html', {
        'form': form,
        'neft_transactions': neft_transactions,
    })

def get_account_name(request):
    account_number = request.GET.get('account_number')
    try:
        profile = UserProfile.objects.get(account_number=account_number)
        return JsonResponse({'name': profile.user.get_full_name()}, status=200)
    except UserProfile.DoesNotExist:
        return JsonResponse({'error': 'Account not found'}, status=404)

#Download statement
@login_required
def account_statement(request):
    user = request.user

    sent = Transaction.objects.filter(sender=user)
    received = Transaction.objects.filter(receiver=user)

    transactions = sent.union(received).order_by('-timestamp')  # Newest first

    balance = user.userprofile.balance  # Start from current balance
    history = []

    for tx in transactions:
        if tx.receiver == user:
            if tx.sender is None:
                tx_type = 'deposit'
            else:
                tx_type = 'credit'
            balance -= tx.amount  # reverse
        else:
            tx_type = 'debit'
            balance += tx.amount  # reverse

        history.append({
            'tx': tx,
            'balance': balance + tx.amount if tx_type in ['credit', 'deposit'] else balance - tx.amount,
            'tx_type': tx_type,
        })

    return render(request, 'bank1/statement.html', {
        'transactions': history,
    })




@login_required
def download_statement(request):
    user = request.user
    transactions = Transaction.objects.filter(sender=user) | Transaction.objects.filter(receiver=user)
    transactions = transactions.order_by('-timestamp')

    template_path = 'bank1/statement_pdf.html'
    context = {'transactions': transactions, 'user': user}
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="account_statement.pdf"'

    template = get_template(template_path)
    html = template.render(context)

    pisa_status = pisa.CreatePDF(html, dest=response)
    if pisa_status.err:
        return HttpResponse('We had some errors <pre>' + html + '</pre>')
    return response       

# Beneficiaries 
@login_required
def beneficiary_dashboard(request, pk=None):
    # Edit case
    if pk:
        instance = get_object_or_404(Beneficiary, pk=pk, user=request.user)
    else:
        instance = None

    if request.method == "POST":
        form = BeneficiaryForm(request.POST, instance=instance)
        if form.is_valid():
            beneficiary = form.save(commit=False)
            beneficiary.user = request.user

            # Set type based on what is filled
            if form.cleaned_data.get('upi_id'):
                beneficiary.type = 'upi'
            else:
                beneficiary.type = 'bank'

            # 🔍 Try to find a matching user to link
            upi = form.cleaned_data.get('upi_id')
            acc = form.cleaned_data.get('account_number')
            ifsc = form.cleaned_data.get('ifsc')

            from django.contrib.auth.models import User
            matched_user = None

            if upi:
                matched_user = User.objects.filter(userprofile__upi_id=upi).first()
            elif acc and ifsc:
                matched_user = User.objects.filter(
                    userprofile__account_number=acc,
                    userprofile__ifsc=ifsc
                ).first()

            beneficiary.beneficiary_user = matched_user  # may be None
            beneficiary.save()

            messages.success(request, "Beneficiary saved successfully.")
            return redirect('beneficiary_dashboard')
    else:
        form = BeneficiaryForm(instance=instance)

    beneficiaries = Beneficiary.objects.filter(user=request.user)

    return render(request, 'bank1/list_beneficiaries.html', {
        'form': form,
        'beneficiaries': beneficiaries,
        'editing': bool(pk) or request.method == "POST",
    })

@login_required
def edit_beneficiary(request, pk):
    beneficiary = get_object_or_404(Beneficiary, pk=pk, user=request.user)

    if request.method == 'POST':
        if 'delete' in request.POST:
            beneficiary.delete()
            messages.success(request, "Beneficiary deleted.")
            return redirect('beneficiary_dashboard')

        form = BeneficiaryForm(request.POST, instance=beneficiary)
        if form.is_valid():
            beneficiary = form.save(commit=False)
            beneficiary.user = request.user

            # Set type based on filled fields
            if form.cleaned_data.get('upi_id'):
                beneficiary.type = 'upi'
            else:
                beneficiary.type = 'bank'

            # Try to link to a registered user
            upi = form.cleaned_data.get('upi_id')
            acc = form.cleaned_data.get('account_number')
            ifsc = form.cleaned_data.get('ifsc')

            matched_user = None
            if upi:
                matched_user = User.objects.filter(userprofile__upi_id=upi).first()
            elif acc and ifsc:
                matched_user = User.objects.filter(
                    userprofile__account_number=acc,
                    userprofile__ifsc=ifsc
                ).first()

            beneficiary.beneficiary_user = matched_user  # Could be None
            beneficiary.save()

            messages.success(request, "Beneficiary updated successfully.")
            return redirect('beneficiary_dashboard')
        else:
            messages.error(request, "Form is invalid.")
    else:
        form = BeneficiaryForm(instance=beneficiary)

    transactions = Transaction.objects.filter(sender=request.user).order_by('-timestamp')[:5]

    return render(request, 'bank1/edit_overlay.html', {
        'form': form,
        'beneficiary': beneficiary,
        'transactions': transactions,  
    })


@login_required
def pay_beneficiary(request, pk):
    beneficiary = get_object_or_404(Beneficiary, pk=pk)
    user_profile = request.user.userprofile

    if request.method == 'POST':
        amount_input = request.POST.get('amount')
        method = request.POST.get('method')

        try:
            amount = Decimal(amount_input)
            if amount <= 0:
                raise ValueError("Invalid amount")
        except (InvalidOperation, ValueError):
            return render(request, 'bank1/pay_beneficiary.html', {
                'beneficiary': beneficiary,
                'error': 'Enter a valid amount.'
            })

        if user_profile.balance < amount:
            return render(request, 'bank1/pay_beneficiary.html', {
                'beneficiary': beneficiary,
                'error': 'Insufficient balance.'
            })

        # Deduct from sender
        user_profile.balance -= amount
        user_profile.save()

        # Credit to receiver
        if hasattr(beneficiary.user, 'userprofile'):
            receiver_profile = beneficiary.user.userprofile
            receiver_profile.balance += amount
            receiver_profile.save()

        # Create transaction for sender (debit)
        Transaction.objects.create(
            sender=request.user,
            receiver=beneficiary.user,
            amount=amount,
            method=method,
            tx_type='debit'
        )

        # Create transaction for receiver (credit)
        Transaction.objects.create(
            sender=request.user,
            receiver=beneficiary.user,
            amount=amount,
            method=method,
            tx_type='credit'
        )

        return redirect('payment_success')

    return render(request, 'bank1/pay_beneficiary.html', {'beneficiary': beneficiary})